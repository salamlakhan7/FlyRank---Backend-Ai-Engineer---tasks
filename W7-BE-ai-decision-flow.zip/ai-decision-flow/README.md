# AI Decision Flow — React Flow + Inngest

Visual AI workflow builder: each node is a decision step that asks an LLM a
YES/NO question and branches down the matching edge. React Flow renders the
graph; Inngest executes it step by step; the OpenAI SDK (pointed at Groq's
OpenAI-compatible endpoint) makes the actual decision calls.

## Project structure

```
ai-decision-flow/
├── client/          # React + Vite frontend — the visual flow editor
│   └── src/
├── server/          # Express + Inngest — runs the workflow, calls the LLM
│   └── inngest/
└── README.md
```

## Phase 1 — Setup

### 1. Install dependencies

```bash
cd server && npm install
cd ../client && npm install
```

### 2. Configure environment variables

```bash
cd server
cp .env.example .env
# then edit .env and paste your real GROQ_API_KEY
```

### 3. Run everything (3 terminals)

```bash
# Terminal 1 — backend
cd server && npm run dev

# Terminal 2 — Inngest dev server (local orchestration UI)
cd server && npm run inngest:dev

# Terminal 3 — frontend
cd client && npm run dev
```

- Frontend: http://localhost:5173
- Backend health check: http://localhost:3001/health
- Inngest dev UI: http://localhost:8288 (shows registered functions + runs)

### Phase 1 deliverables checklist
- [x] Running frontend application (Vite + React + React Flow renders)
- [x] Working Inngest dev server (client configured, endpoint exposed at `/api/inngest`)
- [x] Repository initialized with README

## Why Groq instead of OpenAI directly

The brief asks for the OpenAI SDK. Groq exposes an OpenAI-compatible API, so
`server/inngest/aiClient.js` uses the real `openai` npm package, just pointed
at `https://api.groq.com/openai/v1` with a Groq key. This satisfies "install
and configure the OpenAI SDK" literally while using the provider already set
up. Swap the `baseURL`/`apiKey` in that file if real OpenAI is preferred later.

## Roadmap (next phases)

- **Phase 2 — Foundations:** editable canvas — add/connect nodes, edit node
  prompts, YES/NO edge types, local graph state.
- **Phase 3 — Build (core):** each node maps to an Inngest step; the step
  sends its prompt to the LLM, which must return only `YES` or `NO`; the
  workflow follows the matching edge.
- **Phase 4 — Build (polish):** pick 3+ — visual execution state, logs
  panel, save/load, JSON export, better styling, error handling/retries,
  animated active edges, execution history.
