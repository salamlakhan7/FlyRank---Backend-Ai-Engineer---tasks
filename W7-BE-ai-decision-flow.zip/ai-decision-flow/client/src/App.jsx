import { ReactFlow, Background, Controls } from "@xyflow/react";
import "@xyflow/react/dist/style.css";

// Phase 1 goal: prove the environment is wired up — React Flow renders,
// Tailwind is active, and the app talks to the server's /health endpoint.
// Phase 2 replaces this with the real editable node/edge graph.
const initialNodes = [
  {
    id: "1",
    position: { x: 250, y: 100 },
    data: { label: "Setup OK — Phase 1" },
  },
];

export default function App() {
  return (
    <div className="h-screen w-screen bg-slate-950 text-slate-100">
      <div className="p-4 font-mono text-sm text-emerald-400">
        AI Decision Flow — Phase 1 Setup
      </div>
      <div className="h-[calc(100%-48px)] w-full">
        <ReactFlow nodes={initialNodes} edges={[]} fitView>
          <Background />
          <Controls />
        </ReactFlow>
      </div>
    </div>
  );
}
