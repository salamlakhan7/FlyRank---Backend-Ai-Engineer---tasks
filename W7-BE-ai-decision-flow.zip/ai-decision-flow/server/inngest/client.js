import { Inngest } from "inngest";

// The Inngest client — this is the entry point every workflow function
// registers against. The `id` just namespaces this app in the Inngest dev UI.
export const inngest = new Inngest({ id: "ai-decision-flow" });
