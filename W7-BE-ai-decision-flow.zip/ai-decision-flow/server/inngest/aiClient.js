import OpenAI from "openai";

// Brief asks for the OpenAI SDK — Groq exposes an OpenAI-compatible API,
// so we use the real `openai` package and just point it at Groq's base URL.
// Swap baseURL/apiKey below if you want to use actual OpenAI instead.
export const aiClient = new OpenAI({
  apiKey: process.env.GROQ_API_KEY,
  baseURL: "https://api.groq.com/openai/v1",
});

export const AI_MODEL = "llama-3.3-70b-versatile";
