import "dotenv/config";
import express from "express";
import cors from "cors";
import { serve } from "inngest/express";
import { inngest } from "./inngest/client.js";

const app = express();
app.use(cors());
app.use(express.json());

// Inngest calls this endpoint to run your functions. Right now there are
// no functions registered yet — Phase 3 adds the actual decision-flow
// function here.
app.use("/api/inngest", serve({ client: inngest, functions: [] }));

app.get("/health", (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
  console.log(`Inngest endpoint: http://localhost:${PORT}/api/inngest`);
});
